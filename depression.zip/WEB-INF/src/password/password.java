package password;

public class password { 
    
    
    
    public String getStatus(String pass){
        
      return pass.length()>30?"strong":"weak";  
    }
    
    
    
    
    
    
       
}    